export default function App() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-[#0f172a] border-b border-[#334155] py-8">
        <div className="max-w-7xl mx-auto px-8">
          <h1 className="font-['Plus_Jakarta_Sans'] font-extrabold text-[48px] leading-[48px] tracking-[-1.2px] text-white">
            Sprint<span className="text-[#f97316]">ED</span> Design System
          </h1>
          <p className="font-['Plus_Jakarta_Sans'] font-medium text-[16px] leading-[24px] text-[#94a3b8] mt-4">
            Complete design system extracted from the SprintED educational platform
          </p>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-8 py-16">
        {/* Color Palette */}
        <Section title="Color Palette" subtitle="Primary, Accent, and Neutral Colors">
          <div className="space-y-8">
            {/* Primary Colors */}
            <ColorGroup title="Primary Colors">
              <ColorSwatch color="#2563eb" name="Primary Blue" />
              <ColorSwatch color="#f97316" name="Primary Orange" />
            </ColorGroup>

            {/* Background Colors - Dark */}
            <ColorGroup title="Dark Backgrounds">
              <ColorSwatch color="#020617" name="Slate 950" />
              <ColorSwatch color="#0f172a" name="Slate 900" />
              <ColorSwatch color="#1e293b" name="Slate 800" />
            </ColorGroup>

            {/* Background Colors - Light */}
            <ColorGroup title="Light Backgrounds">
              <ColorSwatch color="#ffffff" name="White" />
              <ColorSwatch color="#f8fafc" name="Slate 50" />
              <ColorSwatch color="#f1f5f9" name="Gray 50" />
              <ColorSwatch color="#fff7ed" name="Orange 50" />
            </ColorGroup>

            {/* Text Colors */}
            <ColorGroup title="Text Colors">
              <ColorSwatch color="#0f172a" name="Primary" />
              <ColorSwatch color="#475569" name="Secondary" />
              <ColorSwatch color="#64748b" name="Tertiary" />
              <ColorSwatch color="#94a3b8" name="Muted" />
              <ColorSwatch color="#cbd5e1" name="Light" />
            </ColorGroup>

            {/* Accent Colors */}
            <ColorGroup title="Accent Colors">
              <ColorSwatch color="#fb923c" name="Orange Light" />
              <ColorSwatch color="#ea580c" name="Orange Dark" />
              <ColorSwatch color="#1e3a8a" name="Blue Dark" />
              <ColorSwatch color="#172554" name="Blue Darker" />
              <ColorSwatch color="#9333ea" name="Purple" />
            </ColorGroup>

            {/* Border Colors */}
            <ColorGroup title="Border Colors">
              <ColorSwatch color="#e2e8f0" name="Slate 200" />
              <ColorSwatch color="#f1f5f9" name="Slate 100" />
              <ColorSwatch color="#334155" name="Slate 700" />
              <ColorSwatch color="#dbeafe" name="Blue 200" />
              <ColorSwatch color="#fed7aa" name="Orange 200" />
            </ColorGroup>
          </div>
        </Section>

        {/* Typography */}
        <Section title="Typography" subtitle="Font Families, Sizes, and Weights">
          <div className="space-y-8">
            <div className="space-y-4">
              <h3 className="font-['Plus_Jakarta_Sans'] font-bold text-[14px] tracking-[0.7px] uppercase text-[#1e3a8a]">
                Font Families
              </h3>
              <div className="space-y-2">
                <p className="font-['Plus_Jakarta_Sans'] text-[16px] text-[#0f172a]">
                  Plus Jakarta Sans (Primary) - The quick brown fox jumps over the lazy dog
                </p>
                <p className="font-['Azeret_Mono'] text-[16px] text-[#0f172a]">
                  Azeret Mono (Monospace) - The quick brown fox jumps over the lazy dog
                </p>
              </div>
            </div>

            {/* Font Sizes */}
            <div className="space-y-4">
              <h3 className="font-['Plus_Jakarta_Sans'] font-bold text-[14px] tracking-[0.7px] uppercase text-[#1e3a8a]">
                Type Scale
              </h3>
              <div className="space-y-6">
                <div>
                  <p className="font-['Plus_Jakarta_Sans'] font-extrabold text-[48px] leading-[48px] tracking-[-1.2px] text-[#0f172a]">
                    48px Hero Heading
                  </p>
                  <span className="text-[12px] text-[#64748b]">ExtraBold, -1.2px tracking</span>
                </div>
                <div>
                  <p className="font-['Plus_Jakarta_Sans'] font-extrabold text-[36px] leading-[40px] tracking-[-0.9px] text-[#0f172a]">
                    36px Section Heading
                  </p>
                  <span className="text-[12px] text-[#64748b]">ExtraBold, -0.9px tracking</span>
                </div>
                <div>
                  <p className="font-['Plus_Jakarta_Sans'] font-extrabold text-[30px] leading-[36px] text-[#0f172a]">
                    30px Subsection Heading
                  </p>
                  <span className="text-[12px] text-[#64748b]">ExtraBold</span>
                </div>
                <div>
                  <p className="font-['Plus_Jakarta_Sans'] font-extrabold text-[24px] leading-[32px] text-[#0f172a]">
                    24px Card Heading
                  </p>
                  <span className="text-[12px] text-[#64748b]">ExtraBold</span>
                </div>
                <div>
                  <p className="font-['Plus_Jakarta_Sans'] font-bold text-[18px] leading-[28px] text-[#0f172a]">
                    18px Card Title
                  </p>
                  <span className="text-[12px] text-[#64748b]">Bold</span>
                </div>
                <div>
                  <p className="font-['Plus_Jakarta_Sans'] font-medium text-[16px] leading-[24px] text-[#475569]">
                    16px Body Text - Regular paragraph content and descriptions
                  </p>
                  <span className="text-[12px] text-[#64748b]">Medium</span>
                </div>
                <div>
                  <p className="font-['Plus_Jakarta_Sans'] font-bold text-[14px] leading-[20px] tracking-[0.7px] uppercase text-[#1e3a8a]">
                    14px Label Text
                  </p>
                  <span className="text-[12px] text-[#64748b]">Bold, uppercase, 0.7px tracking</span>
                </div>
                <div>
                  <p className="font-['Plus_Jakarta_Sans'] font-semibold text-[12px] leading-[16px] text-[#64748b]">
                    12px Small Text - Supporting information and captions
                  </p>
                  <span className="text-[12px] text-[#64748b]">SemiBold</span>
                </div>
              </div>
            </div>
          </div>
        </Section>

        {/* Buttons */}
        <Section title="Buttons" subtitle="Primary, Secondary, and Accent Buttons">
          <div className="flex flex-wrap gap-4">
            <button className="bg-[#2563eb] h-[50px] px-6 rounded-[12px] shadow-[0px_8px_10px_0px_rgba(37,99,235,0.2),0px_20px_25px_0px_rgba(37,99,235,0.2)] font-['Plus_Jakarta_Sans'] font-bold text-[14px] text-white">
              Primary Blue Button
            </button>
            <button className="bg-[#f97316] h-[50px] px-6 rounded-[12px] shadow-[0px_8px_10px_0px_rgba(249,115,22,0.2),0px_20px_25px_0px_rgba(249,115,22,0.2)] font-['Plus_Jakarta_Sans'] font-bold text-[14px] text-white">
              Primary Orange Button
            </button>
            <button className="bg-[#1e293b] h-[50px] px-6 rounded-[12px] border border-[#334155] font-['Plus_Jakarta_Sans'] font-bold text-[14px] text-white">
              Secondary Dark Button
            </button>
          </div>
        </Section>

        {/* Cards */}
        <Section title="Cards" subtitle="Card Components and Layouts">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Light Card */}
            <div className="bg-[#f8fafc] border border-[#e2e8f0] rounded-[12px] p-6">
              <h3 className="font-['Plus_Jakarta_Sans'] font-bold text-[14px] text-[#0f172a] mb-2">
                Light Card Title
              </h3>
              <p className="font-['Plus_Jakarta_Sans'] font-normal text-[12px] text-[#475569] leading-[19.5px]">
                This is a light card with slate background, commonly used for FAQ items and content cards throughout the platform.
              </p>
            </div>

            {/* White Card */}
            <div className="bg-white border border-[#e2e8f0] rounded-[16px] p-6 shadow-[0px_2px_4px_-2px_rgba(0,0,0,0.1),0px_4px_6px_-1px_rgba(0,0,0,0.1)]">
              <h3 className="font-['Plus_Jakarta_Sans'] font-bold text-[18px] leading-[28px] text-[#0f172a] mb-2">
                White Card Title
              </h3>
              <p className="font-['Plus_Jakarta_Sans'] font-normal text-[12px] text-[#64748b] leading-[16px]">
                White cards with subtle shadows are used for instructor profiles and featured content sections.
              </p>
            </div>

            {/* Stat Card */}
            <div className="bg-[#f8fafc] border border-[#e2e8f0] rounded-[16px] p-6">
              <p className="font-['Plus_Jakarta_Sans'] font-extrabold text-[24px] leading-[32px] text-[#0f172a]">
                144% Avg Hike
              </p>
              <p className="font-['Plus_Jakarta_Sans'] font-semibold text-[12px] leading-[16px] text-[#64748b] mt-1">
                Minimum average hike benchmark recorded across data tracks
              </p>
            </div>

            {/* Orange Accent Stat Card */}
            <div className="bg-[#f8fafc] border border-[#e2e8f0] rounded-[16px] p-6">
              <p className="font-['Plus_Jakarta_Sans'] font-extrabold text-[24px] leading-[32px] text-[#ea580c]">
                4.8 Hours
              </p>
              <p className="font-['Plus_Jakarta_Sans'] font-semibold text-[12px] leading-[16px] text-[#64748b] mt-1">
                Average time to complete deep schema and architecture reviews
              </p>
            </div>
          </div>
        </Section>

        {/* Badges */}
        <Section title="Badges & Pills" subtitle="Icon Badges and Label Badges">
          <div className="flex flex-wrap items-center gap-8">
            {/* Circular Badge - Orange */}
            <div className="flex flex-col items-center gap-2">
              <div className="bg-[#f97316] size-[48px] rounded-full flex items-center justify-center shadow-[inset_0px_2px_4px_0px_rgba(0,0,0,0.05)]">
                <span className="font-['Plus_Jakarta_Sans'] font-bold text-[20px] text-white">🎓</span>
              </div>
              <span className="text-[12px] text-[#64748b]">48px Badge</span>
            </div>

            {/* Circular Badge - Blue */}
            <div className="flex flex-col items-center gap-2">
              <div className="bg-[#1e3a8a] size-[96px] rounded-full flex items-center justify-center shadow-[inset_0px_2px_4px_0px_rgba(0,0,0,0.05)]">
                <span className="font-['Plus_Jakarta_Sans'] font-bold text-[24px] leading-[32px] text-white">AM</span>
              </div>
              <span className="text-[12px] text-[#64748b]">96px Avatar</span>
            </div>

            {/* Label Badge */}
            <div className="bg-[rgba(239,246,255,0.6)] border border-[#dbeafe] h-[42px] px-6 rounded-[12px] flex items-center">
              <span className="font-['Plus_Jakarta_Sans'] font-bold text-[12px] leading-[16px] text-[#1e3a8a]">
                1:8 Active Executive Reviews
              </span>
            </div>

            {/* Small Label Badge */}
            <div className="bg-[rgba(239,246,255,0.6)] border border-[#dbeafe] h-[42px] px-4 rounded-[12px] flex items-center">
              <span className="font-['Plus_Jakarta_Sans'] font-bold text-[12px] leading-[16px] text-[#1e3a8a]">
                SprintED Ecosystem
              </span>
            </div>
          </div>
        </Section>

        {/* Spacing */}
        <Section title="Spacing System" subtitle="Standard Gaps and Padding">
          <div className="space-y-4">
            {[
              { value: '4px', label: 'Gap 1' },
              { value: '6px', label: 'Gap 1.5' },
              { value: '8px', label: 'Gap 2' },
              { value: '12px', label: 'Gap 3' },
              { value: '16px', label: 'Gap 4' },
              { value: '32px', label: 'Gap 8' },
              { value: '64px', label: 'Gap 16' },
              { value: '96px', label: 'Gap 24' },
            ].map(({ value, label }) => (
              <div key={label} className="flex items-center gap-4">
                <div className="w-24 font-['Plus_Jakarta_Sans'] font-medium text-[14px] text-[#0f172a]">
                  {label}
                </div>
                <div className="bg-[#2563eb] h-8" style={{ width: value }} />
                <span className="font-['Plus_Jakarta_Sans'] text-[12px] text-[#64748b]">{value}</span>
              </div>
            ))}
          </div>
        </Section>

        {/* Border Radius */}
        <Section title="Border Radius" subtitle="Rounding Values">
          <div className="flex flex-wrap gap-8">
            <div className="flex flex-col items-center gap-2">
              <div className="bg-[#f97316] size-24 rounded-[12px]" />
              <span className="font-['Plus_Jakarta_Sans'] text-[12px] text-[#64748b]">12px - Buttons</span>
            </div>
            <div className="flex flex-col items-center gap-2">
              <div className="bg-[#2563eb] size-24 rounded-[16px]" />
              <span className="font-['Plus_Jakarta_Sans'] text-[12px] text-[#64748b]">16px - Cards</span>
            </div>
            <div className="flex flex-col items-center gap-2">
              <div className="bg-[#1e3a8a] size-24 rounded-full" />
              <span className="font-['Plus_Jakarta_Sans'] text-[12px] text-[#64748b]">9999px - Circles</span>
            </div>
          </div>
        </Section>

        {/* Shadows */}
        <Section title="Shadows" subtitle="Button and Card Shadow Styles">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-[#2563eb] h-[50px] rounded-[12px] shadow-[0px_8px_10px_0px_rgba(37,99,235,0.2),0px_20px_25px_0px_rgba(37,99,235,0.2)] flex items-center justify-center">
              <span className="font-['Plus_Jakarta_Sans'] font-bold text-[14px] text-white">Blue Button Shadow</span>
            </div>
            <div className="bg-[#f97316] h-[50px] rounded-[12px] shadow-[0px_8px_10px_0px_rgba(249,115,22,0.2),0px_20px_25px_0px_rgba(249,115,22,0.2)] flex items-center justify-center">
              <span className="font-['Plus_Jakarta_Sans'] font-bold text-[14px] text-white">Orange Button Shadow</span>
            </div>
            <div className="bg-white h-[100px] rounded-[16px] border border-[#e2e8f0] shadow-[0px_2px_4px_-2px_rgba(0,0,0,0.1),0px_4px_6px_-1px_rgba(0,0,0,0.1)] flex items-center justify-center">
              <span className="font-['Plus_Jakarta_Sans'] font-medium text-[14px] text-[#0f172a]">Card Shadow</span>
            </div>
            <div className="bg-white h-[100px] rounded-[16px] border border-[#e2e8f0] shadow-[0px_8px_10px_-6px_rgba(0,0,0,0.1),0px_20px_25px_-5px_rgba(0,0,0,0.1)] flex items-center justify-center">
              <span className="font-['Plus_Jakarta_Sans'] font-medium text-[14px] text-[#0f172a]">Container Shadow</span>
            </div>
          </div>
        </Section>

        {/* Section Headers */}
        <Section title="Section Headers" subtitle="Overline + Heading + Description Pattern">
          <div className="space-y-12">
            <div className="space-y-4">
              <p className="font-['Plus_Jakarta_Sans'] font-bold text-[14px] tracking-[0.7px] uppercase text-[#1e3a8a]">
                Granular Operations
              </p>
              <h2 className="font-['Plus_Jakarta_Sans'] font-extrabold text-[30px] leading-[36px] text-[#0f172a]">
                How Our Batches Scale
              </h2>
              <p className="font-['Plus_Jakarta_Sans'] font-medium text-[14px] leading-[22.75px] text-[#475569] max-w-2xl">
                We avoid massive, unchecked classrooms. Our operational statistics showcase our firm commitment to maintaining individual attention and practical review paradigms across every cohort.
              </p>
            </div>

            <div className="space-y-4">
              <p className="font-['Plus_Jakarta_Sans'] font-semibold text-[14px] tracking-[0.7px] uppercase text-[#ea580c]">
                The Delta
              </p>
              <h2 className="font-['Plus_Jakarta_Sans'] font-extrabold text-[36px] leading-[40px] tracking-[-0.9px] text-[#0f172a]">
                How SprintED Compares
              </h2>
              <p className="font-['Plus_Jakarta_Sans'] font-medium text-[14px] leading-[20px] text-[#64748b] max-w-2xl">
                Standard structural updates vs traditional, passive methods.
              </p>
            </div>
          </div>
        </Section>

        {/* Grid Layouts */}
        <Section title="Grid Layouts" subtitle="Common Column Configurations">
          <div className="space-y-8">
            {/* 2 Column */}
            <div>
              <p className="font-['Plus_Jakarta_Sans'] font-bold text-[12px] tracking-[0.6px] uppercase text-[#64748b] mb-4">
                2-Column Grid (32px gap)
              </p>
              <div className="grid grid-cols-2 gap-8">
                <div className="bg-[#f8fafc] border border-[#e2e8f0] h-24 rounded-[12px]" />
                <div className="bg-[#f8fafc] border border-[#e2e8f0] h-24 rounded-[12px]" />
              </div>
            </div>

            {/* 3 Column */}
            <div>
              <p className="font-['Plus_Jakarta_Sans'] font-bold text-[12px] tracking-[0.6px] uppercase text-[#64748b] mb-4">
                3-Column Grid (32px gap)
              </p>
              <div className="grid grid-cols-3 gap-8">
                <div className="bg-[#f8fafc] border border-[#e2e8f0] h-24 rounded-[12px]" />
                <div className="bg-[#f8fafc] border border-[#e2e8f0] h-24 rounded-[12px]" />
                <div className="bg-[#f8fafc] border border-[#e2e8f0] h-24 rounded-[12px]" />
              </div>
            </div>

            {/* 4 Column */}
            <div>
              <p className="font-['Plus_Jakarta_Sans'] font-bold text-[12px] tracking-[0.6px] uppercase text-[#64748b] mb-4">
                4-Column Grid (32px gap)
              </p>
              <div className="grid grid-cols-4 gap-8">
                <div className="bg-[#f8fafc] border border-[#e2e8f0] h-24 rounded-[12px]" />
                <div className="bg-[#f8fafc] border border-[#e2e8f0] h-24 rounded-[12px]" />
                <div className="bg-[#f8fafc] border border-[#e2e8f0] h-24 rounded-[12px]" />
                <div className="bg-[#f8fafc] border border-[#e2e8f0] h-24 rounded-[12px]" />
              </div>
            </div>
          </div>
        </Section>
      </div>

      {/* Footer */}
      <footer className="bg-[#020617] border-t border-[#0f172a] py-16 mt-16">
        <div className="max-w-7xl mx-auto px-8">
          <div className="grid grid-cols-4 gap-8">
            <div>
              <h3 className="font-['Plus_Jakarta_Sans'] font-extrabold text-[20px] leading-[28px] tracking-[-0.5px] text-white mb-3">
                Sprint<span className="text-[#f97316]">ED</span>
              </h3>
              <p className="font-['Plus_Jakarta_Sans'] font-medium text-[12px] leading-[16px] text-[#64748b]">
                Complete design system documentation and component library
              </p>
            </div>
            <div>
              <p className="font-['Plus_Jakarta_Sans'] font-bold text-[12px] tracking-[0.6px] uppercase text-white mb-3">
                Components
              </p>
              <div className="space-y-2">
                <p className="font-['Plus_Jakarta_Sans'] font-normal text-[12px] leading-[16px] text-[#94a3b8]">Buttons</p>
                <p className="font-['Plus_Jakarta_Sans'] font-normal text-[12px] leading-[16px] text-[#94a3b8]">Cards</p>
                <p className="font-['Plus_Jakarta_Sans'] font-normal text-[12px] leading-[16px] text-[#94a3b8]">Badges</p>
              </div>
            </div>
            <div>
              <p className="font-['Plus_Jakarta_Sans'] font-bold text-[12px] tracking-[0.6px] uppercase text-white mb-3">
                Design Tokens
              </p>
              <div className="space-y-2">
                <p className="font-['Plus_Jakarta_Sans'] font-normal text-[12px] leading-[16px] text-[#94a3b8]">Colors</p>
                <p className="font-['Plus_Jakarta_Sans'] font-normal text-[12px] leading-[16px] text-[#94a3b8]">Typography</p>
                <p className="font-['Plus_Jakarta_Sans'] font-normal text-[12px] leading-[16px] text-[#94a3b8]">Spacing</p>
              </div>
            </div>
            <div>
              <p className="font-['Plus_Jakarta_Sans'] font-bold text-[12px] tracking-[0.6px] uppercase text-white mb-3">
                Documentation
              </p>
              <p className="font-['Plus_Jakarta_Sans'] font-medium text-[12px] leading-[16px] text-[#64748b]">
                See DESIGN_SYSTEM.md
              </p>
            </div>
          </div>
          <div className="border-t border-[#0f172a] mt-8 pt-8">
            <p className="font-['Plus_Jakarta_Sans'] font-medium text-[12px] leading-[16px] text-[#475569]">
              © 2026 SprintED Design System. Reverse-engineered for documentation.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

function Section({ title, subtitle, children }: { title: string; subtitle: string; children: React.ReactNode }) {
  return (
    <section className="mb-20">
      <div className="mb-8">
        <h2 className="font-['Plus_Jakarta_Sans'] font-extrabold text-[36px] leading-[40px] tracking-[-0.9px] text-[#0f172a] mb-2">
          {title}
        </h2>
        <p className="font-['Plus_Jakarta_Sans'] font-medium text-[14px] leading-[20px] text-[#64748b]">
          {subtitle}
        </p>
      </div>
      {children}
    </section>
  );
}

function ColorGroup({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h3 className="font-['Plus_Jakarta_Sans'] font-bold text-[14px] tracking-[0.7px] uppercase text-[#1e3a8a] mb-4">
        {title}
      </h3>
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {children}
      </div>
    </div>
  );
}

function ColorSwatch({ color, name }: { color: string; name: string }) {
  return (
    <div className="flex flex-col gap-2">
      <div
        className="h-20 rounded-[12px] border border-[#e2e8f0]"
        style={{ backgroundColor: color }}
      />
      <div>
        <p className="font-['Plus_Jakarta_Sans'] font-semibold text-[12px] text-[#0f172a]">{name}</p>
        <p className="font-['Plus_Jakarta_Sans'] font-normal text-[12px] text-[#64748b]">{color}</p>
      </div>
    </div>
  );
}
